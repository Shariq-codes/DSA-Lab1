#include "task5.h"

std::vector<std::vector<int>> generatePascalsTriangle(int n) {
    std::vector<std::vector<int>> t;
    if (n <= 0) return t;

    for (int i = 0; i < n; i++) {
        std::vector<int> r(i + 1, 1);
        for (int j = 1; j < i; j++) {
            r[j] = t[i - 1][j - 1] + t[i - 1][j];
        }
        t.push_back(r);
    }
    return t;
}
