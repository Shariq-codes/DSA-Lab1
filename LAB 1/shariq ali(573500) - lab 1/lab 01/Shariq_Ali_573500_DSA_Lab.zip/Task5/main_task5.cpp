#include <iostream>
#include <vector>
#include "task5.h"

using namespace std;

void printT(int n) {
    vector<vector<int>> t = generatePascalsTriangle(n);
    for (int i = 0; i < t.size(); i++) {
        for (int x : t[i]) {
            cout << x << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int main() {
    printT(0);
    printT(1);
    printT(5);
    return 0;
}
