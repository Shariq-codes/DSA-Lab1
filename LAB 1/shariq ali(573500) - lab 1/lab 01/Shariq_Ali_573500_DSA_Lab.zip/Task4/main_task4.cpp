#include <iostream>
#include <string>
#include "task4.h"

using namespace std;

int main() {
    cout << naiveSearch("hello world", "hello") << endl;
    cout << naiveSearch("hello world", "world") << endl;
    cout << naiveSearch("hello world", "cpp") << endl;
    cout << naiveSearch("hello world", "") << endl;
    return 0;
}
