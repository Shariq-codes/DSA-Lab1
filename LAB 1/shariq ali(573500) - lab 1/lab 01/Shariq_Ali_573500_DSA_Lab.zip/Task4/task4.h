#ifndef TASK4_H
#define TASK4_H

#include <string>

int naiveSearch(std::string s, std::string p);

#endif
