#include "task4.h"

int naiveSearch(std::string s, std::string p) {
    if (p.empty()) return 0;
    int n = s.length();
    int m = p.length();
    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && s[i + j] == p[j]) {
            j++;
        }
        if (j == m) return i;
    }
    return -1;
}
