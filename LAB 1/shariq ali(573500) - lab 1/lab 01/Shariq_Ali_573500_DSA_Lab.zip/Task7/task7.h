#ifndef TASK7_H
#define TASK7_H

#include <vector>

typedef std::vector<std::vector<int>> Matrix;

Matrix multiplyStandard(Matrix A, Matrix B);
Matrix multiplyStrassen(Matrix A, Matrix B);

#endif
