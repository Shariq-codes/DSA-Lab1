#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "task7.h"

using namespace std;

void printM(Matrix M) {
    for (auto r : M) {
        for (int x : r) {
            cout << x << "	";
        }
        cout << endl;
    }
    cout << endl;
}

int main() {
    srand(time(0));

    Matrix A2 = {{1, 2}, {3, 4}};
    Matrix B2 = {{5, 6}, {7, 8}};
    printM(multiplyStrassen(A2, B2));
    printM(multiplyStandard(A2, B2));

    Matrix A4 = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
    Matrix B4 = {{16, 15, 14, 13}, {12, 11, 10, 9}, {8, 7, 6, 5}, {4, 3, 2, 1}};
    printM(multiplyStrassen(A4, B4));
    printM(multiplyStandard(A4, B4));

    Matrix R1(4, vector<int>(4)), R2(4, vector<int>(4));
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            R1[i][j] = rand() % 10;
            R2[i][j] = rand() % 10;
        }
    }
    printM(multiplyStrassen(R1, R2));
    printM(multiplyStandard(R1, R2));

    return 0;
}
