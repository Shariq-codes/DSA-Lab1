#include "task3.h"

std::vector<int> findAllIndices(int a[], int n, int k) {
    std::vector<int> res;
    for (int i = 0; i < n; i++) {
        if (a[i] == k) {
            res.push_back(i);
        }
    }
    return res;
}
