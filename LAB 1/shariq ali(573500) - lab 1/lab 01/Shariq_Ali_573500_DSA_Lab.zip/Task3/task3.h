#ifndef TASK3_H
#define TASK3_H

#include <vector>

std::vector<int> findAllIndices(int a[], int n, int k);

#endif
