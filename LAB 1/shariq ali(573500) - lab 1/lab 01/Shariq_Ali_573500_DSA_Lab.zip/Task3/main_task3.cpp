#include <iostream>
#include <vector>
#include "task3.h"

using namespace std;

void show(const vector<int>& v) {
    if (v.empty()) {
        cout << "Not found" << endl;
    } else {
        for (int x : v) {
            cout << x << " ";
        }
        cout << endl;
    }
}

int main() {
    int a1[] = {10, 20, 30, 20, 40, 20, 50};
    int n1 = 7;
    vector<int> r1 = findAllIndices(a1, n1, 20);
    show(r1);

    int a2[] = {5, 10, 15, 20};
    int n2 = 4;
    vector<int> r2 = findAllIndices(a2, n2, 99);
    show(r2);

    int a3[] = {};
    int n3 = 0;
    vector<int> r3 = findAllIndices(a3, n3, 10);
    show(r3);

    return 0;
}
