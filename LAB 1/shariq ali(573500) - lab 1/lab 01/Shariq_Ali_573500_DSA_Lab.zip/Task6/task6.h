#ifndef TASK6_H
#define TASK6_H

#include <vector>

std::vector<int> findMode(std::vector<int> a);

#endif
