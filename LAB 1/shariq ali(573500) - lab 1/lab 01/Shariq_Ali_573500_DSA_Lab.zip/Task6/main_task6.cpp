#include <iostream>
#include <vector>
#include "task6.h"

using namespace std;

void printM(vector<int> v) {
    if (v.empty()) {
        cout << "Empty" << endl;
    } else {
        for (int x : v) {
            cout << x << " ";
        }
        cout << endl;
    }
}

int main() {
    vector<int> a1 = {1, 2, 2, 3, 4};
    printM(findMode(a1));

    vector<int> a2 = {1, 1, 2, 2, 3};
    printM(findMode(a2));

    vector<int> a3 = {};
    printM(findMode(a3));

    return 0;
}
