#include "task6.h"
#include <unordered_map>

std::vector<int> findMode(std::vector<int> a) {
    if (a.empty()) return {};

    std::unordered_map<int, int> m;
    int mx = 0;

    for (int x : a) {
        m[x]++;
        if (m[x] > mx) mx = m[x];
    }

    std::vector<int> res;
    for (auto p : m) {
        if (p.second == mx) {
            res.push_back(p.first);
        }
    }
    return res;
}
